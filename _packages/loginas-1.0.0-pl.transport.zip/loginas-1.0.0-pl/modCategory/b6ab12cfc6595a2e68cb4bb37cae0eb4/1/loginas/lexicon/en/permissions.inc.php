<?php
/**
 * Permissions Lexicon Entries for Agenda
 *
 * @package loginas
 * @subpackage lexicon
 */
$_lang['loginas.permission.loginas_loginas_desc'] = 'To login as manager user to a frontend account without a password.';
