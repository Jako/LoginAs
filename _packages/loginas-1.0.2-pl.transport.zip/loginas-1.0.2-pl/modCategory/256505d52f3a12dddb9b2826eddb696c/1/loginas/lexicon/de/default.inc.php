<?php
/**
 * Default Lexicon Entries for LoginAs
 *
 * @package loginas
 * @subpackage lexicon
 */
$_lang['loginas'] = 'LoginAs';
$_lang['loginas.login_as'] = 'Anmelden als';
$_lang['loginas.login_as_desc'] = 'Bitte wählen Sie den Benutzer aus, mit dem Sie sich am Frontend Ihrer MODX-Site anmelden möchten.';
$_lang['loginas.menu'] = 'Anmelden als';
$_lang['loginas.menu_desc'] = 'Als Manager-Benutzer an einem Frontend-Konto ohne Passwort anmelden.';
$_lang['loginas.username'] = 'Benutzername';
